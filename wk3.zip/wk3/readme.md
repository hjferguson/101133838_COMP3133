step1: npm install mocha chai
